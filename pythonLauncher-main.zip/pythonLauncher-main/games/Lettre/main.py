import customtkinter as ctk # type: ignore
import random
import os
import json

# Configuration de la fenêtre principale
ctk.set_appearance_mode("System")
ctk.set_default_color_theme("blue")


class LetterGameApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("Jeu de Lettre")
        self.geometry("600x400")

        # Créer un cadre principal
        self.frame = ctk.CTkFrame(self)
        self.frame.pack(pady=20, padx=20, fill="both", expand=True)

        # Question
        self.question_label = ctk.CTkLabel(self.frame, text="Est-ce que ces lettres sont identiques ?",
                                           font=("Arial", 20))
        self.question_label.pack(pady=20)

        # Conteneur pour les lettres et les boutons
        self.letters_frame = ctk.CTkFrame(self.frame)
        self.letters_frame.pack(pady=20)

        # Lettres
        self.letter1 = ctk.CTkLabel(self.letters_frame, text="", font=("Arial", 40))
        self.letter1.grid(row=0, column=0, padx=50, pady=10)

        self.letter2 = ctk.CTkLabel(self.letters_frame, text="", font=("Arial", 40))
        self.letter2.grid(row=0, column=1, padx=50, pady=10)

        # Boutons pour la lettre 1
        self.true_button1 = ctk.CTkButton(self.letters_frame, text="Vrai",
                                          command=lambda: self.check_answer("Vrai"))
        self.true_button1.grid(row=1, column=0, padx=10)

        self.false_button1 = ctk.CTkButton(self.letters_frame, text="Faux",
                                           command=lambda: self.check_answer("Faux"))
        self.false_button1.grid(row=1, column=1, padx=10)

        # Générer les premières lettres
        self.generate_letters()

        # Bouton pour régénérer les lettres
        self.regenerate_button = ctk.CTkButton(self, text="Régénérer les lettres", command=self.generate_letters)
        self.regenerate_button.pack(pady=20)

    def generate_letters(self):
        # Générer deux lettres aléatoires
        self.letter1.configure(text=random.choice("ABCDEFGHIJKLMNOPQRSTUVWXYZ"))
        
        self.letter2.configure(text=random.choice("ABCDEFGHIJKLMNOPQRSTUVWXYZ"))

    def check_answer(self, user_answer):
        # Vérifier si la réponse est correcte
        correct_answer = "Vrai" if self.letter1.cget("text") == self.letter2.cget("text") else "Faux"
        result = "Correct" if user_answer == correct_answer else "Incorrect"

        # Sauvegarder les résultats
        self.save_data(user_answer, result)

        # Afficher le résultat dans la console
        print(f"Lettres: {self.letter1.cget('text')}, {self.letter2.cget('text')} - Réponse: {user_answer} - {result}")
        
        # Régénérer les lettres automatiquement
        self.generate_letters()



    def save_data(self, user_answer, result):
        data_file_path = "data/lettre_game.json"

        # Créer le répertoire 'data' s'il n'existe pas
        os.makedirs("data", exist_ok=True)

        # Charger les données existantes s'il y en a, sinon démarrer une liste vide
        try:
            if os.path.exists(data_file_path):
                with open(data_file_path, "r") as file:
                    all_data = json.load(file)
            else:
                all_data = []
        except (json.JSONDecodeError, FileNotFoundError):
            # Si le fichier est corrompu ou n'existe pas, on réinitialise à une liste vide
            all_data = []

        # Nouvelle entrée de données
        data = {
            "lettre1": self.letter1.cget("text"),
            "lettre2": self.letter2.cget("text"),
            "reponse": user_answer,
            "result": result
        }

        # Ajouter la nouvelle entrée à la liste des données
        all_data.append(data)

        # Sauvegarder les données dans le fichier JSON
        try:
            with open(data_file_path, "w") as file:
                json.dump(all_data, file, indent=4)
        except Exception as e:
            print(f"Erreur lors de la sauvegarde des données : {e}")


    def on_closing(self):
        self.save_data()
        self.destroy()  # Fermer l'application correctement

if __name__ == "__main__":
    app = LetterGameApp()
    app.mainloop()
